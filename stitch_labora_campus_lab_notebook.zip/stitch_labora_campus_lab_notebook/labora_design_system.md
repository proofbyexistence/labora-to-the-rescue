---
name: "LABORA — Nostalgic Classroom Notebook"
description: "A playful, notebook-paper campus laboratory resource-sharing design system with pastel lavender origami accents, 2HB pencil ink borders, and handwritten Caveat + Patrick Hand typography."
---

## Overview

LABORA ("Every lab. One notebook.") is a campus laboratory resource-sharing platform for college students and faculty approvers. The visual language evokes a **nostalgic classroom notebook**: cream grid-ruled paper, crisp 2HB pencil ink outlines, chalk-soft pastel highlights, folded-paper origami buttons, and lightweight hand-drawn margin doodles. The tone is warm, approachable, and organized—never a dry textbook or sterile enterprise portal.

## Colors

The palette anchors on **cream notebook paper** (`#FBFAF6`) ruled with **faint lavender-gray grid lines** (`#E6E1F2`), **pastel lavender** (`#CDB9F2`) for primary actions and origami surfaces, and **2HB pencil ink** (`#1F1F24`) for all primary text and 2px outlines. Status colors are chalk-soft pastels paired with high-contrast dark ink text and always accompanied by an icon and text label.

```yaml
colors:
  primary: "#CDB9F2"
  on-primary: "#1F1F24"
  primary-soft: "#EADDFF"
  on-primary-soft: "#221240"
  secondary: "#E9DEF8"
  on-secondary: "#1F182B"
  paper: "#FBFAF6"
  on-paper: "#1F1F24"
  grid-line: "#E6E1F2"
  surface: "#FFFFFF"
  on-surface: "#1F1F24"
  surface-variant: "#F7EDFF"
  on-surface-variant: "#372856"
  on-surface-muted: "#47464C"
  ink: "#1F1F24"
  outline: "#1F1F24"
  outline-soft: "#968DA4"
  tape: "#F0E494"
  on-tape: "#373100"
  available-container: "#BDFFDD"
  on-available-container: "#003826"
  limited-container: "#FFEEDE"
  on-limited-container: "#472A00"
  booked-container: "#FFEDEB"
  on-booked-container: "#620F16"
  error: "#BA1A1A"
  on-error: "#FFFFFF"
```

## Typography

Headings use **Caveat** (bold 700) for an authentic, energetic handwritten notebook header feel. Body copy, navigation, and UI controls use **Patrick Hand** (regular 400) at a minimum of `18px` with `1.6` line-height (`29px`) for effortless legibility on grid-lined paper.

```yaml
typography:
  display-lg:
    fontFamily: "Caveat"
    fontSize: 48px
    fontWeight: 700
    lineHeight: 54px
    letterSpacing: -0.5px
  display-lg-mobile:
    fontFamily: "Caveat"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 38px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: "Caveat"
    fontSize: 36px
    fontWeight: 700
    lineHeight: 42px
    letterSpacing: 0px
  headline-lg-mobile:
    fontFamily: "Caveat"
    fontSize: 28px
    fontWeight: 700
    lineHeight: 34px
    letterSpacing: 0px
  headline-md:
    fontFamily: "Caveat"
    fontSize: 28px
    fontWeight: 700
    lineHeight: 34px
    letterSpacing: 0px
  headline-sm:
    fontFamily: "Caveat"
    fontSize: 24px
    fontWeight: 700
    lineHeight: 30px
    letterSpacing: 0px
  title-lg:
    fontFamily: "Patrick Hand"
    fontSize: 22px
    fontWeight: 400
    lineHeight: 30px
    letterSpacing: 0px
  title-md:
    fontFamily: "Patrick Hand"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 28px
    letterSpacing: 0px
  body-lg:
    fontFamily: "Patrick Hand"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 32px
    letterSpacing: 0px
  body-md:
    fontFamily: "Patrick Hand"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 29px
    letterSpacing: 0px
  label-lg:
    fontFamily: "Patrick Hand"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 24px
    letterSpacing: 0.25px
  label-md:
    fontFamily: "Patrick Hand"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 22px
    letterSpacing: 0.25px
  label-sm:
    fontFamily: "Patrick Hand"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0.25px
```

## Layout & Spacing

Mobile-first responsive layout on a 24px notebook grid. On mobile (`< 1024px`), the left "Lab Index" sidebar collapses into a slide-over drawer triggered from the top bar. On desktop (`>= 1024px`), the Lab Index sits as a persistent 240px left column styled like physical notebook divider tabs beside the main content area (max-width `1120px`). Generous breathing room separates sections (`48px`–`56px`) so margin doodles never crowd text.

```yaml
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  section: 56px
```

## Elevation & Depth

Tactile paper depth replaces blurred drop shadows:

- **Cards** sit on `#FFFFFF` paper with a `2px solid #1F1F24` pencil border and a crisp, light offset paper shadow (`4px 4px 0px #E6E1F2` or `3px 3px 0px #1F1F24` subtle ink offset), plus a small translucent masking-tape doodle on one corner.
- **Origami Buttons** have a `2px solid #1F1F24` border, a folded-corner triangle in the top-right corner, and a soft paper offset shadow (`3px 3px 0px #1F1F24`) that lifts slightly on hover (`translate(-1px, -1px)`).
- **Focus States** always display a clearly visible `3px` solid `#1F1F24` (or `#675688` + `#1F1F24` ring) outline with `2px` offset for keyboard accessibility.

## Shapes

Rounded, friendly paper corners with a `14px` radius (`rounded-md`) for cards, `10px` (`rounded`) for origami buttons and inputs, and `9999px` (`rounded-full`) for status pills and role switchers.

```yaml
rounded:
  sm: 6px
  DEFAULT: 10px
  md: 14px
  lg: 18px
  xl: 24px
  full: 9999px
```

## Motion & Micro-interaction

Interactions feel like turning a page or pressing a folded paper tab—snappy, tactile, and free of distracting loops. Buttons lift gently on hover (`150ms`) and press down onto their paper shadow on active (`80ms`). Decorative doodles and the daydream strip remain static.

```yaml
motion:
  state-change:
    duration: 150ms
    delay: 0ms
    timingFunction: ease-out
  paper-press:
    duration: 80ms
    delay: 0ms
    timingFunction: ease-in-out
  drawer-slide:
    duration: 240ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
```

## Voice & Content Strategy

- **Tone:** Friendly, encouraging, student-first, and clear. Write like a helpful lab TA jotting down notes for a classmate.
- **Capitalisation:** Sentence case for headings, buttons, and navigation labels (e.g., "Find a lab", "Request project access", "Can't find the right equipment").
- **Terminology:** Always use `Department > Lab > Equipment type > Item`. Equipment types are strictly: `Instruments`, `Development kits`, `Workstations`, `Safety gear`. Statuses are strictly: `Available`, `Limited`, `Booked`. Access levels are strictly: `Open`, `Needs faculty approval`, `Training required`.
- **Do's and Don'ts:**
  - **Do** mark all decorative doodles and tape graphics with `aria-hidden="true"`.
  - **Do** show status with both an icon and text label (never color alone).
  - **Do** keep minimum `44px` height on all buttons and interactive controls.
  - **Don't** use `Lorem ipsum`, generic corporate buzzwords, or cluttered multi-nested borders.

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Typography** → `@components/typography.html`: `typography-display`, `typography-body`, `typography-label`
